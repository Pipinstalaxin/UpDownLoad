Piptronic runs on the EURGBP M15 chart only. Any other chart will show much different results and most likely lose your money.

Piptronic will work on all account sizes as long as you adjust the lot size according to your account size. For example:

$250-$500 micro account = 0.1 lot size

$500-1000 account = 0.1 to 0.3 lot size

$1000-$2500 account = 0.3 - 0.8 lot size

$2500-$5000 account = 0.0 - 2.0 lot size

$5000+ = 1.0 - 4.0 lot size

If you find the trades taking place are very low, then by all means, raise the lot size.

N0S should be left on at all times as it not only inreases profitability, but reliability as well.

Money Management setting should be left off by default. It has proven to show better results with it off. It will be updated in a future version to work much better, but until then just hold off on this feature.

For 5 digit brokers, you will need to add a zero to take profit, stop loss and the lot size. So they should be 130.0, 460,0 and 1.0 = 0.1 lot size on a 5 digit broker.

FXopen is my recommended broker as they use a 3 pip spread on the EURGBP constantly which is perfect. 

http://www.piptronic.com/fxopen/